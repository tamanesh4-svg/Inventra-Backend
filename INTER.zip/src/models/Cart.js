import mongoose from "mongoose";

const cartItemSchema = new mongoose.Schema({
  product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
  quantity: { type: Number, required: true, min: 1, validate: Number.isInteger }
}, { _id: false });
const cartSchema = new mongoose.Schema({
  seller: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  items: { type: [cartItemSchema], default: [] },
  checkedOut: { type: Boolean, default: false }
}, { timestamps: true, versionKey: false });
export default mongoose.model("Cart", cartSchema);
